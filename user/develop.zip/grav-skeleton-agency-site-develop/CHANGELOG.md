# v1.0.5
## mm/dd/2021

1. [](#bugfix)
    * Added missing `accounts` folder

# v1.0.4
## 02/01/2017

1. [](#bugfix)
    * Remove autofocus from the contact form to prevent scrolling

# v1.0.3
## 07/22/2016

1. [](#new)
    * Change the skeleton to use the Form plugin instead of simpleform

# v1.0.2
## 09/22/2015

1. [](#new)
    * Added landing page for SimpleForm

# v1.0.1
## 04/24/2015

1. [](#bugfix)
    * Blueprint typos
    * Removed unneeded markdown files
    * Portfolio page fixes

# v1.0.0
## 01/08/2015

1. [](#new)
    * ChangeLog started...
