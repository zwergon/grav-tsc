---
title: Services
menu: Services
class: small
services:
    - header: E-Commerce
      icon: shopping-cart
      text: Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima maxime quam architecto quo inventore harum ex magni, dicta impedit.
    - header: Responsive Design
      icon: laptop
      text: Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima maxime quam architecto quo inventore harum ex magni, dicta impedit.
    - header: Web Security
      icon: lock
      text: Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima maxime quam architecto quo inventore harum ex magni, dicta impedit.
---

## Services
### Lorem ipsum dolor sit amet consectetur
