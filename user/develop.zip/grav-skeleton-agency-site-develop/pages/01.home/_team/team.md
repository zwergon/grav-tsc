---
title: Team
menu: Team
people:
    - name: Kay Garland
      pic: 1.jpg
      position: Lead Designer
      social:
        - title: twitter
          url: '#'
        - title: facebook
          url: '#'
        - title: stack-overflow
          url: '#'

    - name: Larry Parker
      pic: 2.jpg
      position: Lead Marketer
      social:
        - title: twitter
          url: '#'
        - title: facebook
          url: '#'
        - title: linkedin
          url: '#'

    - name: Diana Petersen
      pic: 3.jpg
      position: Lead Developer
      social:
        - title: twitter
          url: '#'
        - title: facebook
          url: '#'
        - title: google-plus
          url: '#' 
description: Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut eaque, laboriosam veritatis, quos non quis ad perspiciatis, totam corporis ea, alias ut unde.          
---

## Our Amazing Team
### Lorem ipsum dolor sit amet consectetur.
